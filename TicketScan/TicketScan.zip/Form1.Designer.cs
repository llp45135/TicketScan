﻿namespace TicketScan
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox_source = new System.Windows.Forms.PictureBox();
            this.pictureBox_work1 = new System.Windows.Forms.PictureBox();
            this.label_result = new System.Windows.Forms.Label();
            this.pictureBox_slpit1 = new System.Windows.Forms.PictureBox();
            this.pictureBox_slpit2 = new System.Windows.Forms.PictureBox();
            this.pictureBox_slpit3 = new System.Windows.Forms.PictureBox();
            this.pictureBox_slpit4 = new System.Windows.Forms.PictureBox();
            this.pictureBox_slpit5 = new System.Windows.Forms.PictureBox();
            this.pictureBox_slpit6 = new System.Windows.Forms.PictureBox();
            this.pictureBox_slpit7 = new System.Windows.Forms.PictureBox();
            this.pictureBox_work2 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.pictureBox_work3 = new System.Windows.Forms.PictureBox();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.pictureBox_ticket = new System.Windows.Forms.PictureBox();
            this.pictureBox_code = new System.Windows.Forms.PictureBox();
            this.flowLayoutPanel_codeimgs = new System.Windows.Forms.FlowLayoutPanel();
            this.button13 = new System.Windows.Forms.Button();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_source)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_work1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_slpit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_slpit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_slpit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_slpit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_slpit5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_slpit6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_slpit7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_work2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_work3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_ticket)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_code)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox_source
            // 
            this.pictureBox_source.Location = new System.Drawing.Point(526, 12);
            this.pictureBox_source.Name = "pictureBox_source";
            this.pictureBox_source.Size = new System.Drawing.Size(439, 124);
            this.pictureBox_source.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox_source.TabIndex = 0;
            this.pictureBox_source.TabStop = false;
            // 
            // pictureBox_work1
            // 
            this.pictureBox_work1.Location = new System.Drawing.Point(526, 142);
            this.pictureBox_work1.Name = "pictureBox_work1";
            this.pictureBox_work1.Size = new System.Drawing.Size(439, 110);
            this.pictureBox_work1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox_work1.TabIndex = 1;
            this.pictureBox_work1.TabStop = false;
            // 
            // label_result
            // 
            this.label_result.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label_result.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_result.Location = new System.Drawing.Point(19, 133);
            this.label_result.Name = "label_result";
            this.label_result.Size = new System.Drawing.Size(420, 37);
            this.label_result.TabIndex = 2;
            // 
            // pictureBox_slpit1
            // 
            this.pictureBox_slpit1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox_slpit1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox_slpit1.Name = "pictureBox_slpit1";
            this.pictureBox_slpit1.Size = new System.Drawing.Size(59, 50);
            this.pictureBox_slpit1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox_slpit1.TabIndex = 3;
            this.pictureBox_slpit1.TabStop = false;
            // 
            // pictureBox_slpit2
            // 
            this.pictureBox_slpit2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox_slpit2.Location = new System.Drawing.Point(77, 12);
            this.pictureBox_slpit2.Name = "pictureBox_slpit2";
            this.pictureBox_slpit2.Size = new System.Drawing.Size(59, 50);
            this.pictureBox_slpit2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox_slpit2.TabIndex = 4;
            this.pictureBox_slpit2.TabStop = false;
            // 
            // pictureBox_slpit3
            // 
            this.pictureBox_slpit3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox_slpit3.Location = new System.Drawing.Point(142, 12);
            this.pictureBox_slpit3.Name = "pictureBox_slpit3";
            this.pictureBox_slpit3.Size = new System.Drawing.Size(59, 50);
            this.pictureBox_slpit3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox_slpit3.TabIndex = 5;
            this.pictureBox_slpit3.TabStop = false;
            // 
            // pictureBox_slpit4
            // 
            this.pictureBox_slpit4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox_slpit4.Location = new System.Drawing.Point(207, 12);
            this.pictureBox_slpit4.Name = "pictureBox_slpit4";
            this.pictureBox_slpit4.Size = new System.Drawing.Size(59, 50);
            this.pictureBox_slpit4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox_slpit4.TabIndex = 6;
            this.pictureBox_slpit4.TabStop = false;
            // 
            // pictureBox_slpit5
            // 
            this.pictureBox_slpit5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox_slpit5.Location = new System.Drawing.Point(272, 12);
            this.pictureBox_slpit5.Name = "pictureBox_slpit5";
            this.pictureBox_slpit5.Size = new System.Drawing.Size(59, 50);
            this.pictureBox_slpit5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox_slpit5.TabIndex = 7;
            this.pictureBox_slpit5.TabStop = false;
            // 
            // pictureBox_slpit6
            // 
            this.pictureBox_slpit6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox_slpit6.Location = new System.Drawing.Point(337, 12);
            this.pictureBox_slpit6.Name = "pictureBox_slpit6";
            this.pictureBox_slpit6.Size = new System.Drawing.Size(59, 50);
            this.pictureBox_slpit6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox_slpit6.TabIndex = 8;
            this.pictureBox_slpit6.TabStop = false;
            // 
            // pictureBox_slpit7
            // 
            this.pictureBox_slpit7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox_slpit7.Location = new System.Drawing.Point(402, 12);
            this.pictureBox_slpit7.Name = "pictureBox_slpit7";
            this.pictureBox_slpit7.Size = new System.Drawing.Size(59, 50);
            this.pictureBox_slpit7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox_slpit7.TabIndex = 9;
            this.pictureBox_slpit7.TabStop = false;
            // 
            // pictureBox_work2
            // 
            this.pictureBox_work2.Location = new System.Drawing.Point(526, 258);
            this.pictureBox_work2.Name = "pictureBox_work2";
            this.pictureBox_work2.Size = new System.Drawing.Size(439, 114);
            this.pictureBox_work2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox_work2.TabIndex = 10;
            this.pictureBox_work2.TabStop = false;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(19, 201);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(88, 37);
            this.button1.TabIndex = 11;
            this.button1.Text = "读取";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(113, 201);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(88, 37);
            this.button2.TabIndex = 12;
            this.button2.Text = "1 灰   度";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(19, 289);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(88, 37);
            this.button3.TabIndex = 13;
            this.button3.Text = "4 二值化";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(113, 289);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(88, 37);
            this.button4.TabIndex = 14;
            this.button4.Text = "5 分   割";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(19, 332);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(88, 37);
            this.button5.TabIndex = 15;
            this.button5.Text = "识别票号";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(19, 244);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(88, 37);
            this.button6.TabIndex = 16;
            this.button6.Text = "2 去背景";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(113, 244);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(88, 37);
            this.button7.TabIndex = 17;
            this.button7.Text = "3 去干扰";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // pictureBox_work3
            // 
            this.pictureBox_work3.Location = new System.Drawing.Point(526, 378);
            this.pictureBox_work3.Name = "pictureBox_work3";
            this.pictureBox_work3.Size = new System.Drawing.Size(439, 114);
            this.pictureBox_work3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox_work3.TabIndex = 18;
            this.pictureBox_work3.TabStop = false;
            // 
            // button8
            // 
            this.button8.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(19, 375);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(88, 37);
            this.button8.TabIndex = 19;
            this.button8.Text = "连续执行";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(19, 418);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(182, 37);
            this.button9.TabIndex = 27;
            this.button9.Text = "保存字模";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog";
            this.openFileDialog.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog_FileOk);
            // 
            // button10
            // 
            this.button10.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.Location = new System.Drawing.Point(113, 375);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(88, 37);
            this.button10.TabIndex = 28;
            this.button10.Text = "循环执行";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.Location = new System.Drawing.Point(229, 201);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(102, 37);
            this.button11.TabIndex = 29;
            this.button11.Text = "去除底色";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.Location = new System.Drawing.Point(229, 289);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(102, 37);
            this.button12.TabIndex = 30;
            this.button12.Text = "提取21位码";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // pictureBox_ticket
            // 
            this.pictureBox_ticket.Location = new System.Drawing.Point(1000, 28);
            this.pictureBox_ticket.Name = "pictureBox_ticket";
            this.pictureBox_ticket.Size = new System.Drawing.Size(469, 314);
            this.pictureBox_ticket.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox_ticket.TabIndex = 31;
            this.pictureBox_ticket.TabStop = false;
            // 
            // pictureBox_code
            // 
            this.pictureBox_code.Location = new System.Drawing.Point(19, 478);
            this.pictureBox_code.Name = "pictureBox_code";
            this.pictureBox_code.Size = new System.Drawing.Size(438, 60);
            this.pictureBox_code.TabIndex = 32;
            this.pictureBox_code.TabStop = false;
            // 
            // flowLayoutPanel_codeimgs
            // 
            this.flowLayoutPanel_codeimgs.AutoScroll = true;
            this.flowLayoutPanel_codeimgs.Location = new System.Drawing.Point(19, 557);
            this.flowLayoutPanel_codeimgs.Name = "flowLayoutPanel_codeimgs";
            this.flowLayoutPanel_codeimgs.Size = new System.Drawing.Size(1401, 180);
            this.flowLayoutPanel_codeimgs.TabIndex = 33;
            // 
            // button13
            // 
            this.button13.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.Location = new System.Drawing.Point(113, 332);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(88, 37);
            this.button13.TabIndex = 34;
            this.button13.Text = "识别21位码";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.radioButton1.ForeColor = System.Drawing.Color.White;
            this.radioButton1.Location = new System.Drawing.Point(83, 182);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(47, 18);
            this.radioButton1.TabIndex = 35;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "RED";
            this.radioButton1.UseVisualStyleBackColor = false;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.radioButton2.ForeColor = System.Drawing.Color.White;
            this.radioButton2.Location = new System.Drawing.Point(24, 182);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(53, 18);
            this.radioButton2.TabIndex = 36;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "BLUE";
            this.radioButton2.UseVisualStyleBackColor = false;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // button14
            // 
            this.button14.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.Location = new System.Drawing.Point(229, 246);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(133, 37);
            this.button14.TabIndex = 37;
            this.button14.Text = "截取21位码图像";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button15
            // 
            this.button15.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.Location = new System.Drawing.Point(229, 335);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(184, 37);
            this.button15.TabIndex = 38;
            this.button15.Text = "识别21位码（行）";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1528, 770);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.flowLayoutPanel_codeimgs);
            this.Controls.Add(this.pictureBox_code);
            this.Controls.Add(this.pictureBox_ticket);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.pictureBox_work3);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox_work2);
            this.Controls.Add(this.pictureBox_slpit7);
            this.Controls.Add(this.pictureBox_slpit6);
            this.Controls.Add(this.pictureBox_slpit5);
            this.Controls.Add(this.pictureBox_slpit4);
            this.Controls.Add(this.pictureBox_slpit3);
            this.Controls.Add(this.pictureBox_slpit2);
            this.Controls.Add(this.pictureBox_slpit1);
            this.Controls.Add(this.label_result);
            this.Controls.Add(this.pictureBox_work1);
            this.Controls.Add(this.pictureBox_source);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_source)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_work1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_slpit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_slpit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_slpit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_slpit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_slpit5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_slpit6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_slpit7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_work2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_work3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_ticket)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_code)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox_source;
        private System.Windows.Forms.PictureBox pictureBox_work1;
        private System.Windows.Forms.Label label_result;
        private System.Windows.Forms.PictureBox pictureBox_slpit1;
        private System.Windows.Forms.PictureBox pictureBox_slpit2;
        private System.Windows.Forms.PictureBox pictureBox_slpit3;
        private System.Windows.Forms.PictureBox pictureBox_slpit4;
        private System.Windows.Forms.PictureBox pictureBox_slpit5;
        private System.Windows.Forms.PictureBox pictureBox_slpit6;
        private System.Windows.Forms.PictureBox pictureBox_slpit7;
        private System.Windows.Forms.PictureBox pictureBox_work2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.PictureBox pictureBox_work3;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.PictureBox pictureBox_ticket;
        private System.Windows.Forms.PictureBox pictureBox_code;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel_codeimgs;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
    }
}

